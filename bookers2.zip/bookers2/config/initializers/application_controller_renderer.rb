# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = '6e26517006cdee099403195416ae4a89ed8c60a10cd94d548a2804a00e2dd74cf31c41a0931fad523610b90f52cb607a07a6386d1c05057bda2a4d58e7988c27'
Refile.secret_key = '1bd0927bfd9e6df342af3e3220f79b9acc95500afa1c3ec7508b33cece286b1e3608e7c09017e19b82dc3168230df811fc1d49d50a2869dcf6625adcab0db20d'
Refile.secret_key = '8961eb35c6edd2fd8ea32aedf55fd0ec587b00f90f9f8218fe3245d5a71bd4742699095b7d21c1b12e22636ef038206a6d48de6aebdc5e6af0e5fda5ac52a671'
Refile.secret_key = '66bea734e1c083e7b8be670e95def96fc71f87e20b87333b77022424864e7653460e9e45563c6d661f9929072ac5b67e424e4da2029971ee7e6a8d85cd4bbd23'
Refile.secret_key = '3d1610af1cb8e1dea1fef417d79643cfabee3934d3836474959c90e843e7c2bd18a89d172fa3bac1154e489c9d2fc59c496ec7acb6b5d80fb51561fb5258cd36'